package org.example;

import com.owlike.genson.Genson;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import org.hyperledger.fabric.contract.Context;
import org.hyperledger.fabric.contract.ContractInterface;
import org.hyperledger.fabric.contract.annotation.Contact;
import org.hyperledger.fabric.contract.annotation.Contract;
import org.hyperledger.fabric.contract.annotation.Default;
import org.hyperledger.fabric.contract.annotation.Info;
import org.hyperledger.fabric.contract.annotation.License;
import org.hyperledger.fabric.contract.annotation.Transaction;
import org.hyperledger.fabric.shim.ChaincodeException;
import org.hyperledger.fabric.shim.ChaincodeStub;
import org.hyperledger.fabric.shim.ledger.CompositeKey;
import org.hyperledger.fabric.shim.ledger.KeyValue;
import org.hyperledger.fabric.shim.ledger.QueryResultsIterator;

@Contract(
    name = "DarkStoreContract",
    info = @Info(
        title = "Dark Store Event Logging Contract",
        description = "Records fulfillment events and verifies SLA compliance for quick-commerce orders.",
        version = "1.0.0",
        license = @License(name = "Apache-2.0"),
        contact = @Contact(name = "Example Org")
    )
)
@Default
public class DarkStoreContract implements ContractInterface {

    private static final Genson GENSON = new Genson();

    private static final String EVENT_OBJECT_TYPE = "orderEvent";
    private static final String VIOLATION_OBJECT_TYPE = "slaViolation";

    private static final String ORDER_PLACED = "ORDER_PLACED";
    private static final String ORDER_PACKED = "ORDER_PACKED";
    private static final String ORDER_DELIVERED = "ORDER_DELIVERED";
    private static final String SLA_VIOLATION_EVENT = "SLA_VIOLATION";

    private static final long PACKING_SLA_MILLIS = 10L * 60L * 1000L;
    private static final long DELIVERY_SLA_MILLIS = 30L * 60L * 1000L;

    @Transaction(intent = Transaction.TYPE.SUBMIT)
    public OrderEvent recordOrderPlaced(final Context ctx, final String orderId, final String storeId,
            final long timestamp) {
        return recordOrderEvent(ctx, orderId, storeId, timestamp, ORDER_PLACED);
    }

    @Transaction(intent = Transaction.TYPE.SUBMIT)
    public OrderEvent recordOrderPacked(final Context ctx, final String orderId, final String storeId,
            final long timestamp) {
        return recordOrderEvent(ctx, orderId, storeId, timestamp, ORDER_PACKED);
    }

    @Transaction(intent = Transaction.TYPE.SUBMIT)
    public OrderEvent recordOrderDelivered(final Context ctx, final String orderId, final String storeId,
            final long timestamp) {
        return recordOrderEvent(ctx, orderId, storeId, timestamp, ORDER_DELIVERED);
    }

    @Transaction(intent = Transaction.TYPE.EVALUATE)
    public OrderEvent[] queryOrderHistory(final Context ctx, final String orderId) {
        validateRequired(orderId, "orderId");

        final List<OrderEvent> events = getAllOrderEvents(ctx, orderId);
        events.sort(Comparator.comparingLong(OrderEvent::getTimestamp));
        return events.toArray(new OrderEvent[0]);
    }

    @Transaction(intent = Transaction.TYPE.SUBMIT)
    public SLAResult verifySLA(final Context ctx, final String orderId) {
        validateRequired(orderId, "orderId");

        final OrderEvent placedEvent = getRequiredEvent(ctx, orderId, ORDER_PLACED);
        final OrderEvent packedEvent = getRequiredEvent(ctx, orderId, ORDER_PACKED);
        final OrderEvent deliveredEvent = getRequiredEvent(ctx, orderId, ORDER_DELIVERED);

        final long packingDurationMillis = calculateDuration(placedEvent, packedEvent, ORDER_PACKED);
        final long deliveryDurationMillis = calculateDuration(placedEvent, deliveredEvent, ORDER_DELIVERED);

        final boolean packingViolated = packingDurationMillis > PACKING_SLA_MILLIS;
        final boolean deliveryViolated = deliveryDurationMillis > DELIVERY_SLA_MILLIS;

        final String violationType = determineViolationType(packingViolated, deliveryViolated);
        final SLAResult result = new SLAResult(orderId, !packingViolated && !deliveryViolated, violationType,
                packingDurationMillis, deliveryDurationMillis);

        if (!result.isSlaSatisfied()) {
            persistViolation(ctx, result);
        }

        return result;
    }

    private OrderEvent recordOrderEvent(final Context ctx, final String orderId, final String storeId,
            final long timestamp, final String eventType) {
        validateRequired(orderId, "orderId");
        validateRequired(storeId, "storeId");

        if (timestamp <= 0L) {
            throw new ChaincodeException("timestamp must be a positive epoch value");
        }

        final ChaincodeStub stub = ctx.getStub();
        final String eventKey = eventCompositeKey(stub, orderId, eventType).toString();
        final String existingState = stub.getStringState(eventKey);
        if (existingState != null && !existingState.isBlank()) {
            throw new ChaincodeException(String.format("Event %s already exists for order %s", eventType, orderId));
        }

        final OrderEvent orderEvent = new OrderEvent(orderId, eventType, timestamp, storeId);
        stub.putStringState(eventKey, orderEvent.toJson());
        return orderEvent;
    }

    private List<OrderEvent> getAllOrderEvents(final Context ctx, final String orderId) {
        final List<OrderEvent> events = new ArrayList<>();
        final ChaincodeStub stub = ctx.getStub();
        QueryResultsIterator<KeyValue> iterator = null;

        try {
            iterator = stub.getStateByPartialCompositeKey(EVENT_OBJECT_TYPE, orderId);
            for (KeyValue entry : iterator) {
                events.add(OrderEvent.fromJson(entry.getStringValue()));
            }
        } catch (Exception e) {
            throw new ChaincodeException("Failed to query order history for order " + orderId, e);
        } finally {
            if (iterator != null) {
                try {
                    iterator.close();
                } catch (Exception e) {
                    throw new ChaincodeException("Failed to close order history iterator for order " + orderId, e);
                }
            }
        }

        return events;
    }

    private OrderEvent getRequiredEvent(final Context ctx, final String orderId, final String eventType) {
        final OrderEvent event = getOrderEvent(ctx, orderId, eventType);
        if (event == null) {
            throw new ChaincodeException(String.format("Required event %s was not found for order %s", eventType,
                    orderId));
        }
        return event;
    }

    private OrderEvent getOrderEvent(final Context ctx, final String orderId, final String eventType) {
        final ChaincodeStub stub = ctx.getStub();
        final String eventJson = stub.getStringState(eventCompositeKey(stub, orderId, eventType).toString());
        if (eventJson == null || eventJson.isBlank()) {
            return null;
        }
        return OrderEvent.fromJson(eventJson);
    }

    private long calculateDuration(final OrderEvent startEvent, final OrderEvent endEvent, final String endEventType) {
        final long duration = endEvent.getTimestamp() - startEvent.getTimestamp();
        if (duration < 0L) {
            throw new ChaincodeException(String.format("%s timestamp cannot be earlier than ORDER_PLACED",
                    endEventType));
        }
        return duration;
    }

    private String determineViolationType(final boolean packingViolated, final boolean deliveryViolated) {
        if (packingViolated && deliveryViolated) {
            return "PACKING_AND_DELIVERY_SLA_BREACH";
        }
        if (packingViolated) {
            return "PACKING_SLA_BREACH";
        }
        if (deliveryViolated) {
            return "DELIVERY_SLA_BREACH";
        }
        return "NONE";
    }

    private void persistViolation(final Context ctx, final SLAResult result) {
        final ChaincodeStub stub = ctx.getStub();
        final String violationKey = violationCompositeKey(stub, result.getOrderId(), result.getViolationType())
                .toString();
        final String payload = GENSON.serialize(result);

        stub.putStringState(violationKey, payload);
        stub.setEvent(SLA_VIOLATION_EVENT, payload.getBytes(StandardCharsets.UTF_8));
    }

    private CompositeKey eventCompositeKey(final ChaincodeStub stub, final String orderId, final String eventType) {
        return stub.createCompositeKey(EVENT_OBJECT_TYPE, orderId, eventType);
    }

    private CompositeKey violationCompositeKey(final ChaincodeStub stub, final String orderId,
            final String violationType) {
        return stub.createCompositeKey(VIOLATION_OBJECT_TYPE, orderId, violationType);
    }

    private void validateRequired(final String value, final String fieldName) {
        if (value == null || value.isBlank()) {
            throw new ChaincodeException(fieldName + " is required");
        }
    }
}
